//  Clases SIEMPRE en singular

class Empresa{
    //  Ejemplos Netflix, Disney Plus, Amazon Prime Video, HBO, Stremio
}

class Cuenta{
    //  Cuentas con personas permitidas
}

class Pelicula{
    //  Peliculas que pueden ver los usuarios
}