class Empresa {
    constructor(nombre, anioCreacion, fundador) {
        this.nombre = nombre;
        this.anioCreacion = anioCreacion;
        this.fundador = fundador;
        this.cuentas = [];
        //  cuentaS, ya que representa una coleccion de cuentas
    }
    agregarCuenta(cuenta){
        this.cuentas.push(cuenta);
    }
}
class Cuenta {
    constructor(nombreTitular, tipoCuenta, diasGratis){
        this.nombreTitular = nombreTitular;
        this.tipoCuenta = tipoCuenta;
        this.diasGratis = diasGratis;
        this.peliculasVistas = [];
        //  peliculaSVistaS, ya que representa una coleccion de peliculas
    }
    verPelicula(pelicula){
        this.peliculasVistas.push(pelicula);
    }
}
class Pelicula {
    constructor(nombre, duracion, nombreDirector, genero){
        this.nombre = nombre;
        this.duracion = duracion;
        this.nombreDirector = nombreDirector;
        this.genero = genero;
    }
}