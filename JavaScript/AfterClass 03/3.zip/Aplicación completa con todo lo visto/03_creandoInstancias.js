class Empresa {
    constructor(nombre, anioCreacion, fundador) {
        this.nombre = nombre;
        this.anioCreacion = anioCreacion;
        this.fundador = fundador;
        this.cuentas = [];
    }
    agregarCuenta(cuenta) {
        this.cuentas.push(cuenta);
    }
}

class Cuenta {
    constructor(nombreTitular, tipoCuenta, diasGratis) {
        this.nombreTitular = nombreTitular;
        this.tipoCuenta = tipoCuenta;
        this.diasGratis = diasGratis;
        this.peliculasVistas = [];
    }
    verPelicula(pelicula) {
        this.peliculasVistas.push(pelicula);
    }
}

class Pelicula {
    constructor(nombre, duracion, nombreDirector, genero) {
        this.nombre = nombre;
        this.duracion = Number(duracion);
        this.nombreDirector = nombreDirector;
        this.genero = genero;
    }
}

//=================================================================

//  Creo empresa pidiendo datos por prompt

/* const nombreEmpresa = prompt("Ingrese el nombre de la empresa");
const anioCreacion = Number(prompt("Ingrese el año de creacion"));
const nombreFundador = prompt("Ingrese el nombre del fundador");

const javascriptVideo = new Empresa(nombreEmpresa, anioCreacion, nombreFundador);

console.log(javascriptVideo); */

const netflix = new Empresa("Netflix", 1997, "Reed Hastings");

//=================================================================

//  Creo cuentas

const cuenta1 = new Cuenta("Juan", "Silver", 10);
const cuenta2 = new Cuenta("Luis", "Exclusive", 30);
const cuenta3 = new Cuenta("Pia", "Exclusive", 10);
const cuenta4 = new Cuenta("Hugo", "Silver", 10);

//  Agrego cuentas

netflix.agregarCuenta(cuenta1);
netflix.agregarCuenta(cuenta2);
netflix.agregarCuenta(cuenta3);
netflix.agregarCuenta(cuenta4);

//=================================================================

/* let opcion = prompt("Ingrese 1 para agregar cuentas o Enter para salir")

while (opcion == "1") {
    const nombreTitular = prompt("Ingrese el nombre del titular");
    const tipoCuenta = prompt("Ingrese el tipo de cuenta");
    let diasGratis = 0;
    if(tipoCuenta == "Gold"){
        diasGratis = 30;
    } else {
        diasGratis = 10;
    }
    const cuentaCreada = new Cuenta(nombreTitular, tipoCuenta, diasGratis);
    netflix.agregarCuenta(cuentaCreada);
    opcion = prompt("Ingrese 1 para agregar cuentas o Enter para salir")
}

//  Muestro cuentas

console.log(netflix.cuentas); */

//  forEach == por cada uno

// netflix.cuentas.forEach(cuenta => console.log(cuenta));

//=================================================================

//  Creo Peliculas

const pelicula1 = new Pelicula("Memento", 115, "Christopher Nolan", "Suspenso");
const pelicula2 = new Pelicula("American History X", 120, "Tony Kaye", "Drama");

//  "veo" peliculas

cuenta1.verPelicula(pelicula1);
cuenta1.verPelicula(pelicula2);

cuenta2.verPelicula(pelicula2);

/* console.log(cuenta1);
console.log(cuenta2); */

//=================================================================

//  Muestro minutos totales vistos de la cuenta1

const totalMinutosVistos = cuenta1.peliculasVistas.reduce((acumulador, pelicula) => acumulador + pelicula.duracion, 0);

//  El 0 del final indica con que valor iniciar

// console.log(totalMinutosVistos);

//=================================================================

//  El CEO se levanto de buenas y le dio Cuentas Gold a todos sus usuarios que tenian cuentas Silver

/* netflix.cuentas.map(cuenta => {
    if (cuenta.tipoCuenta == "Silver") {
        cuenta.tipoCuenta = "Gold";
        cuenta.diasGratis = 30;
    }
});

console.log(netflix); */

//=================================================================

//  Necesito ver todo mis usuarios que tienen cuentas Exclusive

const cuentasExclusive = netflix.cuentas.filter(cuenta => cuenta.tipoCuenta == "Exclusive")

// console.log(cuentasExclusive);

//  Ahora quiero ver el nombre de esas cuentas

cuentasExclusive.forEach(cuenta => console.log(cuenta.nombreTitular));