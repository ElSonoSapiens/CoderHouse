//---------------------- USUARIO Y CONTRASEÑA

let usuario = prompt("Hola. ¿Cómo te llamás?");
while(usuario ==""){
	usuario=prompt("Debés ingresar tu nombre");
}
let entrada = prompt("Hola "+ usuario +" ingresá la contraseña (entrar)");
while(entrada !="entrar"){
	alert("Contraseña Incorrecta");
	entrada = prompt("Hola "+ usuario +" ingresá la contraseña (entrar)");
}

//---------------------- CONTROL FICHAJE

alert(usuario + " te doy la bienvenida a la plataforma de fichaje y control de empleados");

//----- FUNCION CONSTRUCTORA

function Empleado(nombre, edad, genero, tarde, jus, injus) {
    this.nombre = nombre;
    this.edad = edad;
    this.genero = genero;
    this.tarde = tarde;
    this.jus = jus;
    this.injus = injus;
}

//----- OBJETOS

const ramiro = {
    nombre : "Ramiro",
    apellido : "Perez",
    edad : 27,
    genero : "Masculino",
    tarde : 2,
    jus : 1,
    injus : 0,
};

let docRamiro = document.querySelector("#ramiro .container");

docRamiro.innerHTML = `
    <h3><b>${ramiro.nombre} ${ramiro.apellido}</b></h3>
    <p>${ramiro.edad} Años</p>`

//-----

const laura = {
    nombre : "Laura",
    apellido : "Antona",
    edad : 31,
    genero : "Femenino",
    tarde : 0,
    jus : 0,
    injus : 0,
}

let docLaura = document.querySelector("#laura .container");

docLaura.innerHTML = `
    <h3><b>${laura.nombre} ${laura.apellido}</b></h3>
    <p>${laura.edad} Años</p>`

//-----

const juan = {
    nombre : "Juan",
    apellido : "Valente",
    edad : 23,
    genero : "Masculino",
    tarde : 2,
    jus : 1,
    injus : 0,
}

let docJuan = document.querySelector("#juan .container");

docJuan.innerHTML = `
    <h3><b>${juan.nombre} ${juan.apellido}</b></h3>
    <p>${juan.edad} Años</p> `

//-----

const marcelo = {
    nombre : "Marcelo",
    apellido : "Cotti",
    edad : 25,
    genero : "Masculino",
    tarde : 1,
    jus : 2,
    injus : 1,
}

let docMarcelo = document.querySelector("#marcelo .container");

docMarcelo.innerHTML = `
    <h3><b>${marcelo.nombre} ${marcelo.apellido}</b></h3>
    <p>${marcelo.edad} Años</p> `

//-----

const romina = {
    nombre : "Romina",
    apellido : "Conti",
    edad : 21,
    genero : "Femenino",
    tarde : 3,
    jus : 0,
    injus : 1,
}

let docRomina = document.querySelector("#romina .container");

docRomina.innerHTML = `
    <h3><b>${romina.nombre} ${romina.apellido}</b></h3>
    <p>${romina.edad} Años</p> `

//----- PROMEDIO

const promedio = {
    nombre:"Promedio",
    tarde : 0,
    jus : 0,
    injus : 0,
}

let docPromedio = document.querySelector("#promedios");

//----- ARRAY

const empleados = [ramiro,laura,juan,marcelo,romina];
const empleadosMasc=[];
const empleadosFem=[];

//----- NUEVOS OBJETOS

const florencia={
    nombre : "Florencia",
    apellido : "Perez",
    edad : 24,
    genero : "Femenino",
    tarde : 2,
    jus : 1,
    injus : 0,
}

let docFlorencia = document.querySelector("#florencia .container");

docFlorencia.innerHTML = `
    <h3><b>${florencia.nombre} ${florencia.apellido}</b></h3>
    <p>${florencia.edad} Años</p> `

//-----

const joaquin={
    nombre : "Joaquin",
    apellido : "Lugli",
    edad : 23,
    genero : "Masculino",
    tarde : 1,
    jus : 0,
    injus : 0,
}

let docjoaquin = document.querySelector("#joaquin .container");

docjoaquin.innerHTML = `
    <h3><b>${joaquin.nombre} ${joaquin.apellido}</b></h3>
    <p>${joaquin.edad} Años</p>  `

//----- PUSH NUEVOS OBJETOS

empleados.push(florencia)
empleados.push(joaquin)

//----- FUNCIONES

function promTarde(){
	promedio.tarde = (
        empleados[0].tarde+
        empleados[1].tarde+
        empleados[2].tarde+
        empleados[3].tarde+
        empleados[4].tarde+
        empleados[5].tarde+
        empleados[6].tarde) / 7;}

function promJus(){
	promedio.jus = (
        empleados[0].jus+
        empleados[1].jus+
        empleados[2].jus+
        empleados[3].jus+
        empleados[4].jus+
        empleados[5].jus+
        empleados[6].jus) / 7;}

function promInjus(){
	promedio.injus = (
        empleados[0].injus+
        empleados[1].injus+
        empleados[2].injus+
        empleados[3].injus+
        empleados[4].injus+
        empleados[5].injus+
        empleados[6].injus) / 7;}

promTarde();
promJus();
promInjus();

//----- PROMEDIO EN HTML

docPromedio.innerHTML = `
        <h2>Promedio mensual entre todos los empleados</h2>
        <h3>Llegadas tarde: ${promedio.tarde.toFixed(2)}</h3>
        <h3>Ausencias justificadas: ${promedio.jus.toFixed(2)}</h3>
        <h3>Ausencias injustificadas: ${promedio.injus.toFixed(2)}</h3>`


let select = ""

select = document.getElementById("ramiro")
    select.addEventListener("click",clickRamiro)
    function clickRamiro(){   
        nombre.innerHTML = `<h2>Seleccionaste a ${empleados[0].nombre} ${empleados[0].apellido}</h2>`
    seleccionado.innerHTML= `
                            <h3>Llegadas tarde: ${ramiro.tarde.toFixed(2)}</h3>
                            <h3>Ausencias justificadas: ${ramiro.jus.toFixed(2)}</h3>
                            <h3>Ausencias injustificadas: ${ramiro.injus.toFixed(2)}</h3>`
    select.innerHTML = `<style>#ramiro{
                        border: purple;
                        border-style: solid;
                        border-width: 0.3rem;
                        }</style>`
}

select = document.getElementById("laura")
    select.addEventListener("click",clickLaura)
    function clickLaura(){
    nombre.innerHTML = `<h2>Seleccionaste a ${empleados[1].nombre} ${empleados[1].apellido}</h2>`
    seleccionado.innerHTML= `
                            <h3>Llegadas tarde: ${laura.tarde.toFixed(2)}</h3>
                            <h3>Ausencias justificadas: ${laura.jus.toFixed(2)}</h3>
                            <h3>Ausencias injustificadas: ${laura.injus.toFixed(2)}</h3>`
                            select.innerHTML = `<style>#laura{
                                border: purple;
                                border-style: solid;
                                border-width: 0.3rem;
                                }</style>`
};

select = document.getElementById("juan")
    select.addEventListener("click",clickJuan)
    function clickJuan(){
        nombre.innerHTML = `<h2>Seleccionaste a ${empleados[2].nombre} ${empleados[2].apellido}</h2>`
    seleccionado.innerHTML= `
                            <h3>Llegadas tarde: ${juan.tarde.toFixed(2)}</h3>
                            <h3>Ausencias justificadas: ${juan.jus.toFixed(2)}</h3>
                            <h3>Ausencias injustificadas: ${juan.injus.toFixed(2)}</h3>`
                            select.innerHTML = `<style>#juan{
                                border: purple;
                                border-style: solid;
                                border-width: 0.3rem;
                                }</style>`
};

select = document.getElementById("marcelo")
    select.addEventListener("click",clickMarcelo)
    function clickMarcelo(){
        nombre.innerHTML = `<h2>Seleccionaste a ${empleados[3].nombre} ${empleados[3].apellido}</h2>`
    seleccionado.innerHTML= `
                            <h3>Llegadas tarde: ${marcelo.tarde.toFixed(2)}</h3>
                            <h3>Ausencias justificadas: ${marcelo.jus.toFixed(2)}</h3>
                            <h3>Ausencias injustificadas: ${marcelo.injus.toFixed(2)}</h3>`
                            select.innerHTML = `<style>#marcelo{
                                border: purple;
                                border-style: solid;
                                border-width: 0.3rem;
                                }</style>`
};

select = document.getElementById("romina")
    select.addEventListener("click",clickRomina)
    function clickRomina(){
        nombre.innerHTML = `<h2>Seleccionaste a ${empleados[4].nombre} ${empleados[4].apellido}</h2>`
    seleccionado.innerHTML= `
                            <h3>Llegadas tarde: ${romina.tarde.toFixed(2)}</h3>
                            <h3>Ausencias justificadas: ${romina.jus.toFixed(2)}</h3>
                            <h3>Ausencias injustificadas: ${romina.injus.toFixed(2)}</h3>`
                            select.innerHTML = `<style>#romina{
                                border: purple;
                                border-style: solid;
                                border-width: 0.3rem;
                                }</style>`
};

select = document.getElementById("florencia")
    select.addEventListener("click",clickFlorencia)
    function clickFlorencia(){
        nombre.innerHTML = `<h2>Seleccionaste a ${empleados[5].nombre} ${empleados[5].apellido}</h2>`
    seleccionado.innerHTML= `
                            <h3>Llegadas tarde: ${florencia.tarde.toFixed(2)}</h3>
                            <h3>Ausencias justificadas: ${florencia.jus.toFixed(2)}</h3>
                            <h3>Ausencias injustificadas: ${florencia.injus.toFixed(2)}</h3>`
                            select.innerHTML = `<style>#florencia{
                                border: purple;
                                border-style: solid;
                                border-width: 0.3rem;
                                }</style>`
};

select = document.getElementById("joaquin")
    select.addEventListener("click",clickJoaquin)
    function clickJoaquin(){
        nombre.innerHTML = `<h2>Seleccionaste a ${empleados[6].nombre} ${empleados[6].apellido}</h2>`
    seleccionado.innerHTML= `
                            <h3>Llegadas tarde: ${joaquin.tarde.toFixed(2)}</h3>
                            <h3>Ausencias justificadas: ${joaquin.jus.toFixed(2)}</h3>
                            <h3>Ausencias injustificadas: ${joaquin.injus.toFixed(2)}</h3>`
                            select.innerHTML = `<style>#joaquin{
                                border: purple;
                                border-style: solid;
                                border-width: 0.3rem;
                                }</style>`
};


